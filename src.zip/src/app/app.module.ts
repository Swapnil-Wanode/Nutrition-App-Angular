import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PaymentComponent } from './Components/PaymentComponents/payment/payment.component';
import { DietplanComponent } from './Components/DietPlanComponents/dietplan/dietplan.component';
import { NutritionplanComponent } from './Components/NutritionPlanComponents/nutritionplan/nutritionplan.component';
import { WeightlogComponent } from './Components/WeightPlanComponents/weightlog/weightlog.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { DeleteUserComponent } from './Components/UserComponent/deleteuser/delete-user.component';
import { SaveUserComponent } from './Components/UserComponent/saveuser/save-user.component';
import { ViewbyidpaymentComponent } from './Components/PaymentComponents/viewbyidpayment/viewbyidpayment.component';
import { ListpaymentComponent } from './Components/PaymentComponents/listpayment/listpayment.component';
import { AddpaymentComponent } from './Components/PaymentComponents/addpayment/addpayment.component';

@NgModule({
  declarations: [
    AppComponent,
    SaveUserComponent,
    DeleteUserComponent,
    PaymentComponent,
    DietplanComponent,
    NutritionplanComponent,
    WeightlogComponent,
    AddpaymentComponent,
    ViewbyidpaymentComponent,
    ListpaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

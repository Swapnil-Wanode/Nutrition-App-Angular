import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-save-user',
  templateUrl: './save-user.component.html',
  styleUrls: ['./save-user.component.css']
})
export class SaveUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

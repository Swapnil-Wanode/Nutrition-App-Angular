import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nutritionplan',
  templateUrl: './nutritionplan.component.html',
  styleUrls: ['./nutritionplan.component.css']
})
export class NutritionplanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

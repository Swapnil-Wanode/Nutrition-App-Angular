import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weightlog',
  templateUrl: './weightlog.component.html',
  styleUrls: ['./weightlog.component.css']
})
export class WeightlogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

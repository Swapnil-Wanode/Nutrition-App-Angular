import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from 'src/app/Model/login';
import { LoginServiceService } from 'src/app/Services/LoginService/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean = false;
  uname: string;
  //invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router, private router2: ActivatedRoute, private service:LoginServiceService) { }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['priya', Validators.required],
      password: ['', Validators.required]
    });
  }

  // login() {
  //   this.submitted = true;
  //   this.uname=this.loginForm.controls['username'].value;
  //   alert("name is "+this.uname);
  //   if (this.loginForm.invalid) {
  //     return;
  //   }
   
  //   let login:Login = new Login(this.loginForm.controls['username'].value, this.loginForm.controls['password'].value); 

  //   this.service.loginService(login).subscribe((data: { [x: string]: string; }) => {
  //     alert("role is "+JSON.stringify(data["role"]));
  //     alert('jwt: '+JSON.stringify(data["jwt"]));
  //     alert('userid: '+JSON.stringify(data["userid"]));
  //     //set the JWT token in the sessionstorage with name username
  //     sessionStorage.setItem("userid", data["userid"]);
  //     sessionStorage.setItem("jwtk", data["jwt"]);
  //   //  sessionStorage.setItem("role", data["role"]);

  //     this.router.navigate(['list-students']);
  //   },
  //     (    error: any) => {
  //     alert('Invalid login/password entered');
  //   })
  // }
}

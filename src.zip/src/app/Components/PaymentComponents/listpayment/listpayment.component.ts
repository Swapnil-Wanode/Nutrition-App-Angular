import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listpayment',
  templateUrl: './listpayment.component.html',
  styleUrls: ['./listpayment.component.css']
})
export class ListpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

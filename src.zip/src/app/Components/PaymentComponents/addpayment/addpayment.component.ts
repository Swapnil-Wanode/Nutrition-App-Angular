import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addpayment',
  templateUrl: './addpayment.component.html',
  styleUrls: ['./addpayment.component.css']
})
export class AddpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Payment } from 'src/app/Model/Payment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaymentServiceService {

  constructor(private h:HttpClient) { }

  url="http://localhost:9091/pay";

  addPayment(payment:Payment):Observable<any>{
    return this.h.post(this.url+"/add",payment,{responseType:"text"});
  }
  updatePayment(payment:Payment):Observable<any>{
    return this.h.put(this.url+"/update",payment,{responseType:"text"});
  }
  deletePayment(id:number):Observable<any>{
    return this.h.delete<any[]>(this.url+"/delete/"+id);
  }
  findPaymentsById(id:number):Observable<any>{
    return this.h.get<any>(this.url+"/viewbyid/"+id);
  }
  listPayments():Observable<any>{
    return this.h.get<any[]>(this.url+"/viewallpayments");
  }



}

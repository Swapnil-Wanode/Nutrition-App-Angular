import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbyidpayment',
  templateUrl: './viewbyidpayment.component.html',
  styleUrls: ['./viewbyidpayment.component.css']
})
export class ViewbyidpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

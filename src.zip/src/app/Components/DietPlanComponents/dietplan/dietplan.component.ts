import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dietplan',
  templateUrl: './dietplan.component.html',
  styleUrls: ['./dietplan.component.css']
})
export class DietplanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

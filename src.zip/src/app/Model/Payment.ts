export class Payment{

    public id:number;
    public payment:number;
    public discount:number;
    public created_At:Date;
    public updated_At:Date;
    public userId:number;
    public planId:number;

}

	
// 	@Column
// 	private Long userId;
// 	@Column
// 	private Long planId;
